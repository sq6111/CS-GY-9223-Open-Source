"""Chat client API package."""
from chat_client_api.client import ChatClient, get_client, register_client

__version__ = "0.1.0"
