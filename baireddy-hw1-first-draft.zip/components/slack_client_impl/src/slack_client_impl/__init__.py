"""Slack chat client implementation."""
from slack_client_impl.client import SlackClient

__version__ = "0.1.0"
